KITSOHUB 28Q WORKSHOP BUILD — EMAIL/WHATSAPP READY

Use this ZIP for Vercel deployment.

What this version does:
- Keeps the 28-question KitsoHub assessment.
- Keeps guidance-first cluster logic so learners are not prematurely excluded.
- Does not use Google Sheets.
- Lets learners generate results on their phone.
- Lets learners WhatsApp a clean learner summary.
- Lets learners email the fuller text report using their phone's email app.
- Keeps school report preparation manual: facilitator captures incoming WhatsApp/email results after the session.

Important:
- WhatsApp sends a shorter learner summary.
- Email prepares the fuller report.
- Nothing is automatically sent without the learner pressing the WhatsApp/email action.
- The learner may need your WhatsApp number/contact or facilitator email address.

JavaScript syntax check: PASS

